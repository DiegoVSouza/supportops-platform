"""Deterministic retrieval components."""
