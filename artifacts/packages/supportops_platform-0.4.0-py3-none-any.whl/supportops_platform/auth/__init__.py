"""Authentication components."""
