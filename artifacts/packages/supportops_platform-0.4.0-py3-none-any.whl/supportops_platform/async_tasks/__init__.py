"""Asynchronous work adapters."""
